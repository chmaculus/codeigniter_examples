# CodeIgniter Spanish Pack
Paquete de idioma español del framework PHP CodeIgniter
Versión actual: 2.1.4

## Ficheros actuales:
* calendar_lang.php
* date_lang.php
* db_lang.php
* email_lang.php
* form_validation_lang.php
* ftp_lang.php
* imglib_lang.php
* number_lang.php
* migration_lang.php
* profiler_lang.php
* scaffolding_lang.php
* unit_test_lang.php
* upload_lang.php

## Instalacion
* Descarga el paquete de idiomas
* Crea un directorio es 'spanish' dentro de application/languages de tu proyecto
* Copia los archivos descargados
